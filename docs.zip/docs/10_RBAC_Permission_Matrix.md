# ROLE BASED ACCESS CONTROL (RBAC)
# PERMISSION MATRIX DOCUMENT

## Project

Internal Administration & Human Resource Management System (IHRMS)

## Version

1.0

## Status

Approved

---

# 1. PURPOSE

Tài liệu này quy định:

- Vai trò người dùng
- Quyền truy cập
- Giới hạn dữ liệu
- Phân quyền chức năng
- Phân quyền báo cáo
- Phân quyền workflow
- Phân quyền API

Là cơ sở triển khai:

- Django Permission
- JWT Claims
- Middleware Authorization
- Menu Visibility
- API Security

---

# 2. ROLE DEFINITIONS

## R01 - Super Admin

Phạm vi:

Toàn bộ hệ thống.

Quyền:

- Cấu hình hệ thống
- Quản trị người dùng
- Quản trị vai trò
- Quản trị phân quyền
- Truy cập toàn bộ dữ liệu

---

## R02 - System Admin

Phạm vi:

Hạ tầng và kỹ thuật.

Quyền:

- Quản lý tài khoản
- Quản lý phân quyền
- Xem Audit Log
- Xem cấu hình hệ thống

Không được:

- Sửa dữ liệu lương
- Duyệt lương

---

## R03 - HR Manager

Phạm vi:

Toàn bộ dữ liệu nhân sự.

Quyền:

- Quản lý nhân sự
- Tuyển dụng
- Nghỉ phép
- Chấm công
- Hợp đồng
- KPI nhân sự

---

## R04 - HR Officer

Phạm vi:

Dữ liệu nhân sự.

Quyền:

- Tạo
- Cập nhật
- Theo dõi

Không được:

- Duyệt cuối cùng
- Xóa dữ liệu quan trọng

---

## R05 - Finance Officer

Phạm vi:

Lương và mua sắm.

Quyền:

- Xem bảng lương
- Tính lương
- Kiểm tra thanh toán
- Mua sắm

---

## R06 - Department Manager

Phạm vi:

Phòng ban phụ trách.

Quyền:

- Quản lý nhân viên thuộc phòng
- Duyệt nghỉ phép
- Duyệt công
- Quản lý công việc
- Đánh giá KPI

---

## R07 - Employee

Phạm vi:

Dữ liệu cá nhân.

Quyền:

- Xem thông tin cá nhân
- Xin nghỉ phép
- Xem công
- Xem phiếu lương
- Cập nhật hồ sơ cá nhân

---

## R08 - Director

Phạm vi:

Toàn công ty.

Quyền:

- Xem Dashboard
- Phê duyệt cuối cùng
- Xem KPI
- Xem hợp đồng
- Xem báo cáo điều hành

---

# 3. ACTION DEFINITIONS

## C

Create

---

## R

Read

---

## U

Update

---

## D

Delete (Soft Delete)

---

## A

Approve

---

## RJ

Reject

---

## EX

Export

---

## IM

Import

---

## AS

Assign

---

## CL

Close

---

# 4. ORGANIZATION MODULE

| Action | Super Admin | Sys Admin | HR Manager | HR Officer | Finance | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|------------|------------|------------|
| Create | Y | N | Y | N | N | N | N | N |
| Read | Y | Y | Y | Y | N | Y | N | Y |
| Update | Y | N | Y | N | N | N | N | N |
| Delete | Y | N | N | N | N | N | N | N |
| Export | Y | Y | Y | Y | N | N | N | Y |

---

# 5. HUMAN RESOURCE MODULE

## Employee List

| Action | Super Admin | Sys Admin | HR Manager | HR Officer | Finance | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|------------|------------|------------|
| Create | Y | N | Y | Y | N | N | N | N |
| Read All | Y | N | Y | Y | N | N | N | Y |
| Read Own | Y | Y | Y | Y | Y | Y | Y | Y |
| Update | Y | N | Y | Y | N | N | Own | N |
| Delete | Y | N | N | N | N | N | N | N |
| Export | Y | N | Y | Y | N | N | N | Y |

---

## Employee Attachment

| Action | Super Admin | HR Manager | HR Officer | Employee |
|----------|------------|------------|------------|------------|
| Upload | Y | Y | Y | Own |
| Download | Y | Y | Y | Own |
| Delete | Y | Y | N | N |

---

# 6. RECRUITMENT MODULE

| Action | Super Admin | HR Manager | HR Officer | Manager | Director |
|----------|------------|------------|------------|------------|------------|
| Create Request | Y | Y | Y | Y | N |
| Approve Request | Y | N | N | Y | Y |
| Create Vacancy | Y | Y | Y | N | N |
| Candidate Management | Y | Y | Y | N | N |
| Interview Result | Y | Y | Y | Y | Y |
| Offer Approval | Y | Y | N | N | Y |
| Export | Y | Y | Y | N | Y |

---

# 7. ATTENDANCE MODULE

| Action | Super Admin | HR Manager | HR Officer | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|------------|
| Read All | Y | Y | Y | Department | Own | Y |
| Create Adjustment | Y | Y | Y | N | Request | N |
| Approve Adjustment | Y | Y | N | Y | N | N |
| Lock Attendance | Y | Y | N | N | N | N |
| Export | Y | Y | Y | N | N | Y |

---

# 8. LEAVE MODULE

| Action | Super Admin | HR Manager | HR Officer | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|------------|
| Create Request | Y | Y | Y | Y | Y | N |
| Read | Y | Y | Y | Department | Own | Y |
| Approve | Y | Y | N | Y | N | N |
| Reject | Y | Y | N | Y | N | N |
| Cancel Request | Y | Y | Y | N | Own | N |
| Export | Y | Y | Y | N | N | Y |

---

# 9. PAYROLL MODULE

| Action | Super Admin | HR Manager | Finance | Employee | Director |
|----------|------------|------------|------------|------------|------------|
| Read Payroll | Y | Y | Y | Own | Y |
| Create Payroll | Y | Y | Y | N | N |
| Recalculate Payroll | Y | Y | Y | N | N |
| Approve Payroll | Y | N | N | N | Y |
| Lock Payroll | Y | Y | Y | N | N |
| Export Payroll | Y | Y | Y | N | Y |

---

# 10. CONTRACT MODULE

| Action | Super Admin | HR Manager | HR Officer | Employee | Director |
|----------|------------|------------|------------|------------|------------|
| Create Contract | Y | Y | Y | N | N |
| Read Contract | Y | Y | Y | Own | Y |
| Update Contract | Y | Y | Y | N | N |
| Approve Contract | Y | N | N | N | Y |
| Renew Contract | Y | Y | Y | N | N |
| Export | Y | Y | N | N | Y |

---

# 11. DOCUMENT MODULE

| Action | Super Admin | HR Manager | HR Officer | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|------------|
| Create | Y | Y | Y | Y | N | N |
| Read | Y | Y | Y | Y | By Permission | Y |
| Update | Y | Y | Y | N | N | N |
| Approve | Y | Y | N | N | N | N |
| Publish | Y | Y | N | N | N | N |
| Export | Y | Y | Y | Y | N | Y |

---

# 12. TASK MODULE

| Action | Super Admin | Manager | Employee | Director |
|----------|------------|------------|------------|------------|
| Create | Y | Y | Y | Y |
| Assign | Y | Y | N | Y |
| Update Progress | Y | Y | Own | N |
| Complete | Y | Y | Own | N |
| Approve | Y | Y | N | Y |
| View All | Y | Department | Own | All |
| Export | Y | Y | N | Y |

---

# 13. KPI MODULE

| Action | Super Admin | HR Manager | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|
| Create KPI | Y | Y | Y | N | N |
| Assign KPI | Y | Y | Y | N | N |
| Update Actual | Y | Y | Y | Own | N |
| Evaluate KPI | Y | Y | Y | N | N |
| View KPI | Y | Y | Department | Own | All |
| Export KPI | Y | Y | N | N | Y |

---

# 14. ASSET MODULE

| Action | Super Admin | HR Manager | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|
| Create Asset | Y | Y | N | N | N |
| Assign Asset | Y | Y | Y | N | N |
| Return Asset | Y | Y | Y | Own | N |
| Maintenance | Y | Y | N | N | N |
| Dispose Asset | Y | Y | N | N | Y |
| Read Asset | Y | Y | Department | Own | Y |

---

# 15. PROCUREMENT MODULE

| Action | Super Admin | Finance | Manager | Employee | Director |
|----------|------------|------------|------------|------------|------------|
| Create Request | Y | N | Y | Y | N |
| Read Request | Y | Y | Department | Own | Y |
| Approve Budget | Y | Y | N | N | N |
| Approve Final | Y | N | N | N | Y |
| Close Request | Y | Y | N | N | N |
| Export | Y | Y | N | N | Y |

---

# 16. DASHBOARD MODULE

| Dashboard | Super Admin | HR Manager | HR Officer | Finance | Manager | Employee | Director |
|------------|------------|------------|------------|------------|------------|------------|------------|
| Director Dashboard | Y | N | N | N | N | N | Y |
| HR Dashboard | Y | Y | Y | N | N | N | Y |
| Manager Dashboard | Y | N | N | N | Y | N | Y |
| Personal Dashboard | Y | Y | Y | Y | Y | Y | Y |

---

# 17. ADMINISTRATION MODULE

| Action | Super Admin | Sys Admin | Director |
|----------|------------|------------|------------|
| User Management | Y | Y | N |
| Role Management | Y | N | N |
| Permission Management | Y | N | N |
| System Config | Y | Y | N |
| Audit Log | Y | Y | Y |
| Login Log | Y | Y | N |

---

# 18. MICROSOFT 365 MODULE

| Action | Super Admin | Sys Admin | HR Manager | User |
|----------|------------|------------|------------|------------|
| Connect M365 | Y | Y | N | N |
| Sync Users | Y | Y | N | N |
| Send Email | Y | Y | Y | Own |
| Teams Notify | Y | Y | Y | N |
| SharePoint Access | By Permission | By Permission | By Permission | By Permission |

---

# 19. DATA ACCESS MATRIX

## Employee

```text
Chỉ xem dữ liệu cá nhân
```

---

## Department Manager

```text
Chỉ xem nhân viên phòng mình
```

---

## HR Officer

```text
Xem toàn bộ dữ liệu nhân sự
```

Không xem:

```text
Audit hệ thống
Role
Permission
```

---

## HR Manager

```text
Toàn bộ dữ liệu HR
```

---

## Finance

```text
Payroll
Procurement
```

---

## Director

```text
Toàn công ty
```

---

# 20. MENU VISIBILITY MATRIX

## Employee

```text
Dashboard

My Profile

Attendance

Leave

Tasks

KPI

Documents

Payslip
```

---

## Manager

```text
Employee Menu

+

Team

Approvals

Department KPI
```

---

## HR

```text
Human Resources

Recruitment

Attendance

Leave

Contracts
```

---

## Finance

```text
Payroll

Procurement

Reports
```

---

## Director

```text
Executive Dashboard

Executive Reports

Approvals
```

---

# 21. API AUTHORIZATION RULES

Mọi API phải:

✅ Authenticate

✅ Authorize

✅ Validate Role

✅ Validate Data Scope

✅ Log Activity

---

# 22. PERMISSION APPROVAL

Status:

Approved

Ready For:

- Django Permission Implementation
- JWT Claims Design
- Menu Security
- API Authorization
- UAT