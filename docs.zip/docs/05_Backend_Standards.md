# 05_Backend_Standards.md

# BACKEND DEVELOPMENT STANDARDS

## Project

Internal Administration & Human Resource Management System (IHRMS)

## Version

1.0

## Status

Approved

---

# 1. PURPOSE

Tài liệu này quy định:

- Kiến trúc Backend
- Chuẩn lập trình Django
- Chuẩn đặt tên
- Chuẩn viết API
- Chuẩn Repository
- Chuẩn Service
- Chuẩn Validation
- Chuẩn Audit
- Chuẩn Error Handling
- Chuẩn Testing

Tất cả source code phải tuân thủ tài liệu này.

---

# 2. TECHNOLOGY STANDARD

## Backend

```text
Python 3.12
```

---

## Framework

```text
Django 5
```

---

## API

```text
Django REST Framework
```

---

## Database

```text
Microsoft SQL Server
```

---

## Authentication

```text
JWT

Refresh Token

Microsoft Entra ID
```

---

# 3. APPLICATION ARCHITECTURE

## Architectural Style

```text
Modular Monolith
```

---

## Layers

```text
Presentation Layer

↓

API Layer

↓

Service Layer

↓

Repository Layer

↓

Database Layer
```

---

# 4. DJANGO PROJECT STRUCTURE

```text
ihrms/

├── config/
│
├── apps/
│
│   ├── organization/
│   ├── hrm/
│   ├── recruitment/
│   ├── attendance/
│   ├── leave/
│   ├── payroll/
│   ├── contracts/
│   ├── documents/
│   ├── tasks/
│   ├── kpi/
│   ├── assets/
│   ├── procurement/
│   ├── dashboard/
│   ├── notifications/
│   ├── audit/
│   ├── security/
│   ├── m365/
│   └── common/
│
├── media/
│
├── static/
│
├── templates/
│
└── logs/
```

---

# 5. MODULE STRUCTURE

Mỗi module phải có cấu trúc:

```text
module/

├── models/
│
├── repositories/
│
├── services/
│
├── serializers/
│
├── validators/
│
├── permissions/
│
├── api/
│
├── tests/
│
├── urls.py
│
└── apps.py
```

---

# 6. NAMING CONVENTION

## Class

```python
Employee
Department
RecruitmentRequest
```

---

## Serializer

```python
EmployeeSerializer
EmployeeCreateSerializer
EmployeeUpdateSerializer
```

---

## Repository

```python
EmployeeRepository
DepartmentRepository
```

---

## Service

```python
EmployeeService
PayrollService
TaskService
```

---

## API View

```python
EmployeeViewSet
DepartmentViewSet
```

---

## Permission

```python
EmployeePermission
PayrollPermission
```

---

# 7. MODEL DEVELOPMENT STANDARD

## General Rules

Một model tương ứng một bảng.

---

Model phải sử dụng:

```python
UUID hoặc Identity Key
```

theo thiết kế Database.

---

## Audit Fields

Tất cả model nghiệp vụ đều phải có:

```python
created_by

created_date

modified_by

modified_date

deleted_by

deleted_date

is_deleted
```

---

## Soft Delete

Không được xóa dữ liệu vật lý.

Bắt buộc:

```python
is_deleted = True
```

---

# 8. BASE MODEL STANDARD

Tạo Common Base Model dùng chung.

Nội dung:

```text
Audit Fields

Soft Delete

Common Methods
```

Mọi model nghiệp vụ kế thừa từ BaseModel.

---

# 9. REPOSITORY STANDARD

## Mục tiêu

Toàn bộ thao tác dữ liệu phải đi qua Repository.

---

Không được:

```python
Employee.objects.filter(...)
```

trong Service Layer.

---

Bắt buộc:

```python
EmployeeRepository
```

---

## Repository Responsibilities

### Create

Tạo dữ liệu.

---

### Read

Đọc dữ liệu.

---

### Update

Cập nhật dữ liệu.

---

### Soft Delete

Xóa mềm.

---

### Search

Tìm kiếm.

---

### Filter

Lọc dữ liệu.

---

# 10. SERVICE LAYER STANDARD

## Mục tiêu

Business Logic chỉ được viết tại Service Layer.

---

Không được viết:

```python
Business Logic
```

trong:

```python
View

Serializer

Repository
```

---

## Ví dụ

Payroll Calculation

↓

PayrollService

---

Leave Validation

↓

LeaveService

---

Recruitment Workflow

↓

RecruitmentService

---

# 11. VALIDATION STANDARD

## Validation Levels

### API Validation

Kiểm tra dữ liệu đầu vào.

---

### Business Validation

Kiểm tra nghiệp vụ.

---

### Database Validation

Kiểm tra ràng buộc.

---

## Ví dụ

EmployeeCode phải duy nhất.

---

NationalID không được trùng.

---

Contract Date phải hợp lệ.

---

# 12. API DESIGN STANDARD

## RESTFUL API

Bắt buộc.

---

## URL Convention

```text
/api/v1/
```

---

Ví dụ:

```text
/api/v1/employees/

/api/v1/departments/

/api/v1/tasks/
```

---

# 13. HTTP METHOD STANDARD

## GET

Đọc dữ liệu.

---

## POST

Tạo dữ liệu.

---

## PUT

Cập nhật toàn bộ.

---

## PATCH

Cập nhật một phần.

---

## DELETE

Soft Delete.

---

# 14. API RESPONSE STANDARD

## Success

```json
{
    "success": true,
    "message": "Success",
    "data": {}
}
```

---

## Error

```json
{
    "success": false,
    "message": "Validation Error",
    "errors": []
}
```

---

# 15. PAGINATION STANDARD

Bắt buộc cho toàn bộ danh sách.

---

Default

```text
20 records
```

---

Maximum

```text
100 records
```

---

# 16. FILTERING STANDARD

Bắt buộc hỗ trợ:

```text
Keyword

Date Range

Status

Department

Employee
```

nếu phù hợp module.

---

# 17. SORTING STANDARD

Cho phép:

```text
CreatedDate

ModifiedDate

Code

Name
```

---

# 18. SEARCH STANDARD

Search không phân biệt:

```text
Hoa thường

Dấu tiếng Việt
```

---

Hỗ trợ:

```text
Contains Search
```

---

# 19. FILE MANAGEMENT STANDARD

## File Metadata

Lưu SQL Server.

---

## File Content

Lưu:

```text
SharePoint

OneDrive
```

---

Không lưu Binary vào SQL Server.

---

# 20. AUDIT LOG STANDARD

Bắt buộc cho:

```text
Create

Update

Delete

Approve

Reject

Export
```

---

Thông tin lưu:

```text
User

Role

Action

Old Value

New Value

Date Time

IP Address
```

---

# 21. WORKFLOW STANDARD

Các module bắt buộc workflow:

```text
Leave

Recruitment

Contract

Procurement

Document

Payroll Approval
```

---

Workflow phải lưu:

```text
Current Step

Approver

Decision

Date
```

---

# 22. PERMISSION STANDARD

Mọi API phải kiểm tra:

```text
Authentication

Authorization
```

---

Không được:

```text
Bypass Permission
```

---

# 23. PAYROLL STANDARD

Không cho phép:

```text
Tính lương trong View
```

---

Bắt buộc:

```text
Payroll Engine

Payroll Service
```

---

Các bước:

```text
Attendance

↓

Leave

↓

Allowance

↓

Deduction

↓

Tax

↓

Net Salary
```

---

# 24. TASK STANDARD

Task phải hỗ trợ:

```text
Status

Priority

Deadline

Comment

Checklist

Attachment
```

---

Task Overdue phải tự động xác định.

---

# 25. DOCUMENT STANDARD

Mọi tài liệu phải có:

```text
Document Code

Version

Document Category

Status
```

---

Lưu lịch sử phiên bản.

---

# 26. ERROR HANDLING STANDARD

## Không hiển thị

```text
Stack Trace
```

cho người dùng.

---

## Ghi Log

Bắt buộc.

---

## Trả thông báo thân thiện.

---

# 27. LOGGING STANDARD

## Application Log

```text
Info

Warning

Error

Critical
```

---

## Log Storage

```text
logs/
```

---

# 28. EXCEPTION STANDARD

Tạo Common Exception Classes.

```python
ValidationException

NotFoundException

BusinessException

PermissionException
```

---

# 29. TRANSACTION STANDARD

Các nghiệp vụ:

```text
Payroll

Recruitment

Contract

Procurement
```

phải sử dụng:

```python
Database Transaction
```

---

# 30. PERFORMANCE STANDARD

Danh sách:

```text
< 3 giây
```

---

Dashboard:

```text
< 5 giây
```

---

# 31. CACHING RULE

Không triển khai Cache Layer ở phiên bản đầu.

Thiết kế code phải sẵn sàng mở rộng sau này.

---

# 32. UNIT TEST STANDARD

Mỗi:

```text
Repository

Service
```

phải có Unit Test.

---

Coverage tối thiểu:

```text
80%
```

---

# 33. INTEGRATION TEST STANDARD

Bắt buộc cho:

```text
Payroll

Leave

Recruitment

Procurement

Task
```

---

# 34. API DOCUMENTATION

Sử dụng:

```text
Swagger/OpenAPI
```

---

Bắt buộc sinh:

```text
Request

Response

Schema

Authentication
```

---

# 35. CODE QUALITY STANDARD

Tuân thủ:

```text
PEP8
```

---

Không được:

```text
Hard Code

Duplicate Logic

Magic Number
```

---

# 36. SECURITY CODING STANDARD

Không lưu:

```text
Plain Password
```

---

Không log:

```text
Password

Token

Bank Account

National ID
```

---

Không trả về:

```text
Internal Error Detail
```

cho Frontend.

---

# 37. DEVELOPMENT CHECKLIST

Trước khi Merge:

✅ Unit Test Pass

✅ Integration Test Pass

✅ Migration Generated

✅ API Documentation Updated

✅ Permission Checked

✅ Audit Log Checked

✅ Code Review Completed

---

# 38. DEFINITION OF DONE

Một chức năng được xem là hoàn thành khi:

✅ Code hoàn chỉnh

✅ Migration thành công

✅ API hoạt động

✅ Permission đúng

✅ Audit Log hoạt động

✅ Unit Test đạt

✅ Integration Test đạt

✅ Không còn lỗi Critical

✅ Tài liệu được cập nhật

---

# 39. BACKEND APPROVAL

Status:

Approved

Ready For:

- Frontend Standards
- Development
- Code Generation
- Testing