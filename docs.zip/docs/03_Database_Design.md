# 03_Database_Design.md

# DATABASE DESIGN DOCUMENT

## Project

Internal Administration & Human Resource Management System (IHRMS)

## Version

1.1

## Status

FINAL APPROVED

---

# 1. DATABASE OBJECTIVES

Hệ thống cơ sở dữ liệu phục vụ:

- Tổ chức
- Nhân sự
- Tuyển dụng
- Chấm công
- Nghỉ phép
- Tiền lương
- Hợp đồng
- Tài liệu
- Công việc
- KPI
- Tài sản
- Mua sắm
- Dashboard
- Microsoft 365

Quy mô thiết kế:

```text
30 nhân sự hiện tại

Mở rộng đến 200 nhân sự
```

---

# 2. DATABASE PRINCIPLES

## DB-001

Chuẩn hóa dữ liệu.

---

## DB-002

Một nguồn dữ liệu duy nhất.

---

## DB-003

Sử dụng Foreign Key cho toàn bộ quan hệ.

---

## DB-004

Toàn bộ dữ liệu nghiệp vụ hỗ trợ Audit.

---

## DB-005

Toàn bộ dữ liệu nghiệp vụ hỗ trợ Soft Delete.

---

## DB-006

Không lưu file vật lý trong SQL Server.

---

## DB-007

File lưu tại:

```text
SharePoint
OneDrive
```

---

## DB-008

Metadata lưu tại SQL Server.

---

# 3. COMMON AUDIT FIELDS

Tất cả bảng nghiệp vụ phải có:

```sql
CreatedBy
CreatedDate

ModifiedBy
ModifiedDate

DeletedBy
DeletedDate

IsDeleted
```

---

# 4. ORGANIZATION MODULE

## tblOrganization

```sql
OrganizationID PK

OrganizationCode

OrganizationName

Description

IsActive
```

---

## tblDepartment

```sql
DepartmentID PK

DepartmentCode

DepartmentName

OrganizationID FK

ManagerEmployeeID FK

Description

IsActive
```

---

## tblPosition

```sql
PositionID PK

PositionCode

PositionName

Description

IsActive
```

---

## tblJobTitle

```sql
JobTitleID PK

JobTitleCode

JobTitleName

Description

IsActive
```

---

# 5. HUMAN RESOURCE MODULE

## tblEmployee

```sql
EmployeeID PK

EmployeeCode

FirstName

LastName

FullName

DateOfBirth

Gender

NationalID

TaxCode

SocialInsuranceNo

PersonalEmail

CompanyEmail

MobilePhone

Address

JoinDate

LeaveDate

DepartmentID FK

PositionID FK

JobTitleID FK

ManagerID FK

EmploymentStatus

PhotoUrl
```

---

## tblEmployeeBankAccount

```sql
BankAccountID PK

EmployeeID FK

BankName

AccountName

AccountNumber

Branch
```

---

## tblEmployeeEmergencyContact

```sql
EmergencyContactID PK

EmployeeID FK

FullName

Relationship

PhoneNumber

Address
```

---

## tblEmployeeEducation

```sql
EducationID PK

EmployeeID FK

Degree

Major

School

GraduationYear
```

---

## tblEmployeeCertificate

```sql
CertificateID PK

EmployeeID FK

CertificateName

IssuedBy

IssueDate

ExpiryDate
```

---

## tblEmployeeAttachment

```sql
AttachmentID PK

EmployeeID FK

DocumentName

DocumentType

DocumentUrl

FileSize
```

---

## tblEmployeeHistory

```sql
HistoryID PK

EmployeeID FK

HistoryType

EffectiveDate

Description
```

---

## tblEmployeeTransfer

```sql
TransferID PK

EmployeeID FK

FromDepartmentID FK

ToDepartmentID FK

EffectiveDate

Reason
```

---

## tblEmployeePromotion

```sql
PromotionID PK

EmployeeID FK

OldPositionID FK

NewPositionID FK

EffectiveDate

Reason
```

---

## tblEmployeeSalaryHistory

```sql
SalaryHistoryID PK

EmployeeID FK

OldSalary

NewSalary

EffectiveDate

Reason
```

---

## tblEmployeeReward

```sql
RewardID PK

EmployeeID FK

RewardType

RewardDate

Amount

Description
```

---

## tblEmployeeDiscipline

```sql
DisciplineID PK

EmployeeID FK

DisciplineType

DisciplineDate

Description
```

---

# 6. RECRUITMENT MODULE

## tblRecruitmentRequest

```sql
RecruitmentRequestID PK

RequestCode

DepartmentID FK

PositionID FK

RequiredQuantity

RequestReason

RequiredDate

Status
```

---

## tblJobPosting

```sql
JobPostingID PK

RecruitmentRequestID FK

PostingTitle

OpenDate

CloseDate

Status
```

---

## tblCandidate

```sql
CandidateID PK

CandidateCode

FullName

PhoneNumber

Email

CurrentAddress

Source

CVFileUrl

Status
```

---

## tblInterview

```sql
InterviewID PK

CandidateID FK

InterviewDate

InterviewType

InterviewerID FK

Result

Comments
```

---

## tblOffer

```sql
OfferID PK

CandidateID FK

OfferDate

ExpectedJoinDate

SalaryOffer

Status
```

---

# 7. CALENDAR MODULE

## tblHoliday

```sql
HolidayID PK

HolidayCode

HolidayName

HolidayDate

Description

IsActive
```

---

## tblWorkingCalendar

```sql
WorkingCalendarID PK

CalendarYear

WorkingDaysPerMonth

WorkingHoursPerDay

IsDefault
```

---

# 8. ATTENDANCE MODULE

## tblWorkShift

```sql
WorkShiftID PK

ShiftCode

ShiftName

StartTime

EndTime
```

---

## tblAttendance

```sql
AttendanceID PK

EmployeeID FK

AttendanceDate

CheckInTime

CheckOutTime

WorkingHours

Status
```

---

## tblOvertime

```sql
OvertimeID PK

EmployeeID FK

WorkDate

StartTime

EndTime

TotalHours

Status
```

---

## tblAttendanceAdjustment

```sql
AdjustmentID PK

EmployeeID FK

AttendanceDate

Reason

ApprovedBy

Status
```

---

# 9. LEAVE MODULE

## tblLeaveType

```sql
LeaveTypeID PK

LeaveTypeCode

LeaveTypeName

IsPaid
```

---

## tblLeaveRequest

```sql
LeaveRequestID PK

EmployeeID FK

LeaveTypeID FK

FromDate

ToDate

TotalDays

Reason

Status
```

---

## tblLeaveApproval

```sql
ApprovalID PK

LeaveRequestID FK

ApproverID FK

ApprovalLevel

Decision

DecisionDate
```

---

# 10. SALARY STRUCTURE

## tblSalaryGrade

```sql
SalaryGradeID PK

GradeCode

GradeName

Description
```

---

## tblSalaryStructure

```sql
SalaryStructureID PK

SalaryGradeID FK

BasicSalary

PositionAllowance

ResponsibilityAllowance

PhoneAllowance

TransportationAllowance

MealAllowance

EffectiveDate
```

---

## tblEmployeeSalary

```sql
EmployeeSalaryID PK

EmployeeID FK

SalaryGradeID FK

CurrentBasicSalary

EffectiveDate

EndDate

Status
```

---

# 11. PAYROLL MODULE

## tblPayrollPeriod

```sql
PayrollPeriodID PK

PayrollMonth

PayrollYear

StartDate

EndDate

Status
```

---

## tblPayroll

```sql
PayrollID PK

PayrollPeriodID FK

EmployeeID FK

BasicSalary

Allowance

OvertimeAmount

GrossIncome

InsuranceAmount

TaxAmount

DeductionAmount

NetIncome
```

---

## tblPayrollAllowance

```sql
AllowanceID PK

PayrollID FK

AllowanceType

Amount
```

---

## tblPayrollDeduction

```sql
DeductionID PK

PayrollID FK

DeductionType

Amount
```

---

## tblPayslip

```sql
PayslipID PK

PayrollID FK

GeneratedDate

FileUrl
```

---

# 12. CONTRACT MODULE

## tblContractType

```sql
ContractTypeID PK

ContractTypeCode

ContractTypeName
```

---

## tblContract

```sql
ContractID PK

EmployeeID FK

ContractTypeID FK

ContractNo

StartDate

EndDate

BasicSalary

Status
```

---

## tblContractAppendix

```sql
AppendixID PK

ContractID FK

AppendixNo

EffectiveDate

Description
```

---

# 13. DOCUMENT MODULE

## tblDocumentCategory

```sql
CategoryID PK

CategoryCode

CategoryName
```

---

## tblDocument

```sql
DocumentID PK

DocumentNo

DocumentName

CategoryID FK

VersionNo

EffectiveDate

DocumentUrl

Status
```

---

## tblDocumentApproval

```sql
ApprovalID PK

DocumentID FK

ApproverID FK

ApprovalDate

Decision
```

---

# 14. TASK MODULE

## tblTaskStatus

```sql
TaskStatusID PK

StatusCode

StatusName
```

---

## tblTask

```sql
TaskID PK

TaskCode

TaskName

Description

ParentTaskID

CreatedByEmployeeID FK

AssignedToEmployeeID FK

DepartmentID FK

Priority

StartDate

DueDate

TaskStatusID FK
```

---

## tblTaskChecklist

```sql
ChecklistID PK

TaskID FK

ChecklistItem

IsCompleted
```

---

## tblTaskComment

```sql
CommentID PK

TaskID FK

EmployeeID FK

CommentText

CommentDate
```

---

## tblTaskAttachment

```sql
AttachmentID PK

TaskID FK

DocumentUrl

FileName
```

---

# 15. KPI MODULE

## tblKPIPeriod

```sql
KPIPeriodID PK

Year

Quarter

Month
```

---

## tblKPITemplate

```sql
KPITemplateID PK

KPIName

Description

Weight

TargetValue
```

---

## tblCompanyKPI

```sql
CompanyKPIID PK

KPITemplateID FK

KPIPeriodID FK

Target

Actual

Achievement

Score
```

---

## tblDepartmentKPI

```sql
DepartmentKPIID PK

DepartmentID FK

KPITemplateID FK

KPIPeriodID FK

Target

Actual

Achievement
```

---

## tblEmployeeKPI

```sql
EmployeeKPIID PK

EmployeeID FK

KPITemplateID FK

KPIPeriodID FK

Target

Actual

Achievement

Score
```

---

# 16. ASSET MODULE

## tblAssetType

```sql
AssetTypeID PK

AssetTypeCode

AssetTypeName
```

---

## tblAsset

```sql
AssetID PK

AssetCode

AssetName

AssetTypeID FK

PurchaseDate

PurchaseValue

Status
```

---

## tblAssetAllocation

```sql
AllocationID PK

AssetID FK

EmployeeID FK

AssignedDate

ReturnDate
```

---

## tblAssetMaintenance

```sql
MaintenanceID PK

AssetID FK

MaintenanceDate

Description

Cost
```

---

# 17. PROCUREMENT MODULE

## tblProcurementRequest

```sql
ProcurementRequestID PK

RequestNo

RequestedBy FK

DepartmentID FK

RequestDate

Reason

Status
```

---

## tblProcurementItem

```sql
ItemID PK

ProcurementRequestID FK

ItemName

Quantity

EstimatedCost
```

---

## tblProcurementApproval

```sql
ApprovalID PK

ProcurementRequestID FK

ApproverID FK

ApprovalLevel

Decision

DecisionDate
```

---

# 18. NOTIFICATION MODULE

## tblNotification

```sql
NotificationID PK

EmployeeID FK

NotificationType

Title

Message

IsRead

CreatedDate
```

---

# 19. SECURITY MODULE

## tblRole

```sql
RoleID PK

RoleCode

RoleName
```

---

## tblPermission

```sql
PermissionID PK

PermissionCode

PermissionName
```

---

## tblRolePermission

```sql
RolePermissionID PK

RoleID FK

PermissionID FK
```

---

## tblUser

```sql
UserID PK

EmployeeID FK

Username

Email

RoleID FK

IsActive
```

---

## tblDelegation

```sql
DelegationID PK

DelegatorEmployeeID FK

DelegateEmployeeID FK

DelegationFrom

DelegationTo

Reason

Status
```

---

# 20. AUDIT MODULE

## tblAuditLog

```sql
AuditLogID PK

TableName

RecordID

ActionType

OldValue

NewValue

ChangedBy

ChangedDate
```

---

## tblUserLoginLog

```sql
LoginLogID PK

UserID FK

LoginTime

LogoutTime

IPAddress
```

---

# 21. WORKFLOW MODULE

## tblWorkflowDefinition

```sql
WorkflowID PK

WorkflowCode

WorkflowName
```

---

## tblWorkflowStep

```sql
WorkflowStepID PK

WorkflowID FK

StepNo

RoleID FK

StepName
```

---

## tblWorkflowTransaction

```sql
WorkflowTransactionID PK

WorkflowID FK

ReferenceID

CurrentStep

Status
```

---

# 22. RELATIONSHIP SUMMARY

```text
Organization
└── Department

Department
└── Employee

Position
└── Employee

JobTitle
└── Employee

Employee
├── Attendance
├── Leave
├── Payroll
├── Contract
├── EmployeeSalary
├── KPI
└── Asset Allocation

RecruitmentRequest
└── JobPosting

Candidate
└── Interview

Contract
└── ContractAppendix

Task
├── TaskChecklist
├── TaskComment
└── TaskAttachment

Asset
├── AssetAllocation
└── AssetMaintenance
```

---

# 23. INDEX STRATEGY

Tạo Index cho:

```sql
EmployeeCode

NationalID

DepartmentCode

ContractNo

DocumentNo

TaskCode

AssetCode

RequestNo

AttendanceDate

KPIPeriodID

PayrollMonth

PayrollYear

Status
```

---

# 24. DATA RETENTION

## Employee

```text
Permanent
```

---

## Payroll

```text
10 Years
```

---

## Contract

```text
10 Years
```

---

## Audit Log

```text
5 Years
```

---

## Documents

```text
5 Years Minimum
```

---

# 25. DATABASE APPROVAL

Status:

FINAL APPROVED

Version:

1.1

Architecture:

LOCKED

Ready For:

✅ Security Design

✅ Django Models

✅ API Development

✅ UI Development

✅ Testing

✅ Source Code Generation